from .autoref import autoref

__all__ = ['autoref']
